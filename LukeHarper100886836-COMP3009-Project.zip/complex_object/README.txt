/********************************************
*	Name:		Luke Harper
*	Date:		December 07, 2015
*	Course:		COMP 3009
*	Professor:	Doron Nussbaum
*	Project:	Final Project
*********************************************/

External Resources Required:
==========================================
1) OpenGL with freeGlut and Glew (same version used in the class)

Steps to Run

1) Launch the solution file which should load the appropriate version of Visual Studios

2)Ensure freeglut.dll and  glew32.dll are in the debug folder, or linked appropriately

3) Ensure gl is linked and additional includes are specificed in Visual Studios

4) Compile and Run with Local Windows Debugger

============================================

All work is my own except where specified.

Note: Fire animation math as noted in the report was taken from COMP 3501 Fall 2015.

